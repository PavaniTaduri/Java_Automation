package JavaHandson;

public class cat extends Animal {
	

	public void makeSound()
	{
		System.out.println("Meow height is "+height +" and colour is " +colour);
		
	}
}
