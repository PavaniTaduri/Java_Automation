package JavaHandson;

public class testAnimals {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		cat smiley =new cat();
		smiley.height = 10;
		smiley.colour = "blue";
		smiley.makeSound();

	}

}
