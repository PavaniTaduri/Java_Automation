package JavaHandson;

public interface grandDad {
	
	final int shoeSize = 10;

}
