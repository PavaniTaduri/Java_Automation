package JavaHandson;

public class SBI  extends RBI implements Nationalbank{

	

		void calculateFD()
	{
	
		System.out.println("interest rate in SBI is 8%");
		
	}

}

	
		
	


	

	

