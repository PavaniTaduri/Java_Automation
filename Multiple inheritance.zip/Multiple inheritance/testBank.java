package JavaHandson;

public class testBank {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		SBI testBank = new SBI();
		testBank.calculateFD();
		float dr = testBank.readDollarRate();
		System.out.println(dr);
	}

}
