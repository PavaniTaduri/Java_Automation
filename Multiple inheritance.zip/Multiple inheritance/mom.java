package JavaHandson;

public class mom {
	
	 static String eyeColour = "blue";

}
