package JavaHandson;

public class RBI {

	private static float dollarRate = 75f;
	public float readDollarRate()
	{
		return dollarRate;
		
	}
}
