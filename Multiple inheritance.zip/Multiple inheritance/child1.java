package JavaHandson;

public class child1 extends mom implements dada,grandDad {

	public static void main(String[] args) {
	
		
		System.out.println("childs height is" +(dada.height + 10) + " eyecolour inherited from mom is " +eyeColour);
		
		System.out.println("large feet from grandDad" +(shoeSize-1));
	}

}
