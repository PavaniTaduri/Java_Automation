package JavaHandson;

public interface dada {
	
	public static final int height = 155;
	

}
