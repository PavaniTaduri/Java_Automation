package JavaHandson;

public interface Nationalbank {
	
	 static void calculateFD()
	{
	
	}

}
