package JavaHandson;

public class Rectangle extends Shape {
	void calculateArea()
	{

	   int l= 20;
	   int b= 3;
	   
	   int ar = l*b;
	   System.out.println("area of rectangle is "+ar);
	}
}


