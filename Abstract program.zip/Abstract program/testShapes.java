package JavaHandson;

public class testShapes {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
    
		circle circle1 = new circle();
		circle1.calculateArea();
		Rectangle rect1 = new Rectangle();
		rect1.calculateArea();
		
	}

}
