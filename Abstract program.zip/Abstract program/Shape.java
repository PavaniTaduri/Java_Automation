package JavaHandson;

 public abstract class Shape {
	
	void calculateArea()
	{
		
	}

}
