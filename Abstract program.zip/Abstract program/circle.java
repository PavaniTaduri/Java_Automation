package JavaHandson;

public class circle extends Shape {

		
		// TODO Auto-generated method stub
	void calculateArea()
	{
		
		double r = 2;
		double ac = 3.14 * r * r;
		System.out.println("area of circle is "+ac);
	}
		
		

}
